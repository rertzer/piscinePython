from .ft_package import count_in_list

def main():
    count_in_list(['toto'], 'titi')
