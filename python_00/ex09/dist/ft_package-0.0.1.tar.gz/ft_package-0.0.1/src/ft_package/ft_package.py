def count_in_list(lst: list, string: str):
    """
    count_in_list(lst, string) --> int
    count number of occurrences of string in lst
    """
    return lst.count(string)
