This is a tiny useless package.

