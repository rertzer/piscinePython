from setuptools import setup

setup(
	name='ft_package',
	version="0.0.1",
	description='tiny useless package',
	url='https://github.com/rertzer/piscinePython/python_00/ex09',
    author='rertzer',
	author_email='rertzer@student.42.fr',
	license='MIT',
	requires=[],
)
